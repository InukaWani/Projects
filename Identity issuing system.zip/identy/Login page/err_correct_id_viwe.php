<!DOCTYPE html>
<html lang="en"><head>

<style >
table, th, td {
  border: 1px solid black;
  border-radius: 10px;
}

</style>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Header/Header/1.css">
    <link rel="stylesheet" href="../Application form for lost NIC/aplication.css">
    <title>Header</title>
</head>
<body>
	<header>
        <ul>
            <li><img src="../Header/Header/Header_files/id-card.png" alt=""></li>
        
            <li><a href="file:///C:/Users/Administrator/Desktop/Vihanga/header%20gevindu/html/1st.html#">Admin Dashboard</a></li>
            <li><a href="file:///C:/Users/Administrator/Desktop/Vihanga/header%20gevindu/html/1st.html#">Home</a></li>
            <li><a href="file:///C:/Users/Administrator/Desktop/Vihanga/header%20gevindu/html/1st.html#">NIC</a></li>
            <li><a href="file:///C:/Users/Administrator/Desktop/Vihanga/header%20gevindu/html/1st.html#">About</a></li>
            <li><a href="file:///C:/Users/Administrator/Desktop/Vihanga/header%20gevindu/html/1st.html#">Contact</a></li>
            <li><a href="file:///C:/Users/Administrator/Desktop/Vihanga/header%20gevindu/html/1st.html#">Help</a></li>
           
            <li id="contact"><a href="C:\Users\Administrator\Desktop\IWT Assigment\HTML\Login.html">Sign in</a></li>
        </ul>
    </header>
    <body style="background-color:powderblue;"></body>

    <img  class="reglogo" src="../images/reg.png" alt="registration user logo">

    <center>

       
<?php

require 'connection.php';

$sql = "SELECT id,name,address,postalcode,dob,dob_number,id_number,gender,civil,occup,email,contact,err FROM err_corrct_nic";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table><tr>
	<th>id</th>
	<th>name</th>
	<th>address</th>
	<th>postal code </th>
	<th>doate of bir </th>
	<th>Birth Certificate Number  </th>
	<th>id number Number  </th>
	<th> gender </th>
	<th> Civil Status </th>
	<th>  Occupation </th>
	<th>E-mail </th>
	<th>Contact Number</th>
	<th>  err </th>
	 
	 
	</tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["id"]. "</td>
		<td>" . $row["name"]."</td>
		<td>" . $row["address"]. "</td>
		<td>" . $row["postalcode"]."</td>
		<td>" . $row["dob"]."</td>
		<td>" . $row["dob_number"]."</td>
		<td>" . $row["id_number"]."</td>
		<td>" . $row["gender"]."</td>
		<td>" . $row["civil"]."</td>
		<td>" . $row["occup"]."</td>
		<td>" . $row["email"]."</td>
		<td>" . $row["contact"]."</td>
		 	<td>" . $row["err"]."</td>
		 </tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

	$conn->close();
?>
 </center>
</body>
</html>