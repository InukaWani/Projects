<?php


session_start();
$host="localhost";
$username="root";
$passwords='';
$db_name="id";

$conn=mysqli_connect($host, $username, $passwords, $db_name);
if(mysqli_connect_errno()){
    die("Failed to connect with mysql :".mysqli_connect_errno());

}

if(isset($_POST['submit'])){

    $uname = $_POST['user'];
    $passw =($_POST['pass']);

    $sql="SELECT * FROM user WHERE u_name='$uname' && pass='$passw' ";

    $result = mysqli_query($conn, $sql);

    if($result->num_rows > 0){
        $row = mysqli_fetch_array($result);
        header('location:../Admin dashboard/admin dashboard.html');

    }

    else{
        echo "<script>alert('The E-mail and the password does not match.')</script>";
    }

}


?>