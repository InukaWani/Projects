<?php

if(isset($_POST['submit'])){

    $firstname = $_POST['fname'];
    $lastname = $_POST['lname'];
    $user_name = $_POST['user'];
    $passw = $_POST['pass'];
    $cpasswo = $_POST['passa'];
    $email = $_POST['email'];
    $tell = $_POST['tell'];


$host="localhost";
$username="root";
$passwords='';
$db_name="id";

$conn=mysqli_connect($host, $username, $passwords, $db_name);
if(mysqli_connect_errno()){
    die("Failed to connect with mysql :".mysqli_connect_errno());

}

    
           $sql="INSERT INTO user (user_id,f_name,l_name,u_name,pass,email,phone)
           VALUES('$firstname','$lastname','$user_name','$passw','$password','$email','$tell')";

           $result=mysqli_query($conn,$sql);
           header('location:../Login page/Login.html'); 
           if($result){
               echo",<script>alert('Registration completed')
               
            }
               </script>";
           }else{
               echo"<script>alert('something went wrong')
               </script>";
           }
       
       }else{
           echo"<script>alert('Password does not match..')
           </script>";
       }
    

    ?>
