<?php

if(isset($_POST['submit'])){

    
    $full = $_POST['fullname'];
    $addre = $_POST['addres'];
    $postal  = $_POST['postal'];
    $dob  = $_POST['dob'];
    $dob_n  = $_POST['dob_num'];
    $gend  = $_POST['gender'];
    $stu  = $_POST['stu'];
    $occup  = $_POST['ocp'];
    $email  = $_POST['email'];
    $tell  = $_POST['tell'];
    $img  = $_POST['image'];
    


$host="localhost";
$username="root";
$passwords='';
$db_name="id";

$conn=mysqli_connect($host, $username, $passwords, $db_name);
if(mysqli_connect_errno()){
    die("Failed to connect with mysql :".mysqli_connect_errno());

}

    
           $sql="INSERT INTO request_nic (id,name,address,postalcode,dob,dob_number,gender,civill,occup,email,contact,photo)
           VALUES(0,'$full','$addre','$postal','$dob','$dob_n','$gend','$stu','$occup','$email','$tell','$img')";

           $result=mysqli_query($conn,$sql);
           header('location:../Login page/Login.html'); 
           if($result){
               echo",<script>alert('Registration completed')
               
            }
               </script>";
           }else{
               echo"<script>alert('something went wrong')
               </script>";
           }
       
       }else{
           echo"<script>alert('Password does not match..')
           </script>";
       }
    

    ?>
