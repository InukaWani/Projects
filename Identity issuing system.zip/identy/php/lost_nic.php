<?php

if(isset($_POST['submit'])){

    
    $full = $_POST['fullname'];
    $addre = $_POST['addres'];
    $postal  = $_POST['postal'];
    $dob  = $_POST['dob'];
    $dob_n  = $_POST['dob_num'];
    $id  = $_POST['id_number'];
    $gend  = $_POST['gender'];
    $stu  = $_POST['stu'];
    $occup  = $_POST['ocp'];
    $email  = $_POST['email'];
    $tell  = $_POST['tell'];
    
    


$host="localhost";
$username="root";
$passwords='';
$db_name="id";

$conn=mysqli_connect($host, $username, $passwords, $db_name);
if(mysqli_connect_errno()){
    die("Failed to connect with mysql :".mysqli_connect_errno());

}

    
           $sql="INSERT INTO lost_nic (id,name,address,postalcode,dob,dob_number,p_id_number,Gender,civil,occup,email,contact)
           VALUES(0,'$full','$addre','$postal','$dob','$dob_n','$id','$gend','$stu','$occup','$email','$tell')";

           $result=mysqli_query($conn,$sql);
           header('location:../Login page/Login.html'); 
           if($result){
               echo",<script>alert('Registration completed')
               
            }
               </script>";
           }else{
               echo"<script>alert('something went wrong')
               </script>";
           }
       
       }else{
           echo"<script>alert('Password does not match..')
           </script>";
       }
    

    ?>
