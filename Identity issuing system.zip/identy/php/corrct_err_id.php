<?php

if(isset($_POST['submit'])){

 $full = $_POST['fullname'];
    $addre = $_POST['addres'];
    $postal  = $_POST['postal'];
    $dob  = $_POST['dob'];
    $dob_n  = $_POST['dob_num'];
    $idnum  = $_POST['idnumber'];
    $gend  = $_POST['gender'];
    $stu  = $_POST['stu'];
    $occup  = $_POST['ocp'];
    $email  = $_POST['email'];
    $tell  = $_POST['tell'];
    $Err  = $_POST['err'];


$host="localhost";
$username="root";
$passwords='';
$db_name="id";

$conn=mysqli_connect($host, $username, $passwords, $db_name);
if(mysqli_connect_errno()){
    die("Failed to connect with mysql :".mysqli_connect_errno());

}

    
          $sql="INSERT INTO Err_corrct_nic (id,name,address,postalcode,dob,dob_number,id_number,gender,civil,occup,email,contact,err)
           VALUES(0,'$full','$addre','$postal','$dob','$dob_n','$idnum','$gend','$stu','$occup','$email','$tell','$Err')";

           $result=mysqli_query($conn,$sql);
           header('location:../Login page/Login.html'); 
           if($result){
               echo",<script>alert('Registration completed')
               
            }
               </script>";
           }else{
               echo"<script>alert('something went wrong')
               </script>";
           }
       
       }else{
           echo"<script>alert('Password does not match..')
           </script>";
       }
    

    ?>
